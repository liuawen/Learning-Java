class ReviewTest{

	public static void main(String[] args){
		int sum ;
		//for(int i = 1;i <= 100;i++){
			if(4 % 2 != 0){
				//System.out.println(i);
				sum = 1;
			}else{
				sum = 2;
			}
		//}
		System.out.println(sum);

	
	}

}