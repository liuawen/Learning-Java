class ReviewTest{

	public static void main(String[] args){
		char c1 = 'a';
		char c2 = 97;//�����зǳ��ټ�

		System.out.println(c2);

		char c3 = 5;
		char c4 = '5';

		int i1 = (int)c4;
		System.out.println(i1);//53

	}
}