package com.atguigu.java1;

/**
 * @author shkstart
 * @create 2019 上午 11:59
 */
public class StudentDAO extends DAO<Student> {//只能操作某一个表的DAO
}
