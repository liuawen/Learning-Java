package com.atguigu.java;

/**
 * @author shkstart
 * @create 2019 上午 11:18
 */
public class SubOrder1<T> extends Order<T> {//SubOrder1<T>:仍然是泛型类
}
