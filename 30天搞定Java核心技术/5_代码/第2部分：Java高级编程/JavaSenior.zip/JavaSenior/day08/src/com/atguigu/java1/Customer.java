package com.atguigu.java1;

/**
 * @author shkstart
 * @create 2019 上午 11:54
 */
public class Customer { //此类对应数据库中的customers表
}
