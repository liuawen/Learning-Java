package com.atguigu.java2;

/**
 * @author shkstart
 * @create 2019 下午 2:42
 */
public class Student extends Person {
}
