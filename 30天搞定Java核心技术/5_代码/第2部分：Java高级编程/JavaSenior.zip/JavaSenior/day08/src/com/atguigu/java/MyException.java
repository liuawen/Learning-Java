package com.atguigu.java;

/**
 * @author shkstart
 * @create 2019 上午 11:29
 */
//异常类不能声明为泛型类
//public class MyException<T> extends Exception{
//}
