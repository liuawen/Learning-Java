package com.atguigu.java1;

/**
 * @author shkstart
 * @create 2019 上午 11:55
 */
public class CustomerDAO extends DAO<Customer>{//只能操作某一个表的DAO
}
