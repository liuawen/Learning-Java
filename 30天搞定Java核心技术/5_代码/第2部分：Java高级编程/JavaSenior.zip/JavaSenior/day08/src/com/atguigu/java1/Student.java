package com.atguigu.java1;

/**
 * @author shkstart
 * @create 2019 上午 11:58
 */
public class Student {
}
