package com.atguigu.java;

import com.atguigu.bean.Person;

/**
 * @author shkstart
 * @create 2019 上午 11:59
 */
public class ModuleTest {

    public static void main(String[] args) {
        Person p = new Person("Tom",12);
        System.out.println(p);
    }

}
