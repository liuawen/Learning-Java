/**
 * @author shkstart
 * @create 2019 下午 12:00
 */
module day13 {

    requires java9test;
    requires junit;
    requires java.net.http;
}