/**
 * @author shkstart
 * @create 2019 下午 12:01
 */
module java9test {

    exports com.atguigu.bean;
}