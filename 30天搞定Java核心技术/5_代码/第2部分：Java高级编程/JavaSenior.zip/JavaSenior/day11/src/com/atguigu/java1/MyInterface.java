package com.atguigu.java1;

/**
 * @author shkstart
 * @create 2019 下午 3:15
 */

public interface MyInterface {
    void info();
}
