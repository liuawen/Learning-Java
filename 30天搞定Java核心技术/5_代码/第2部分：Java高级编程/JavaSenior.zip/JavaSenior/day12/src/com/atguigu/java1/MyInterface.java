package com.atguigu.java1;

/**
 * 自定义函数式接口
 * @author shkstart
 * @create 2019 下午 2:20
 */
@FunctionalInterface
public interface MyInterface {

    void method1();

//    void method2();
}
