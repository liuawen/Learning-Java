package com.atguigu.java;

/**
 * @author shkstart
 * @create 2019 上午 11:01
 */
public class Person {

    String name;
    int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public Person() {
    }
}
