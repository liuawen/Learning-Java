package com.atguigu.java;

import com.atguigu.Application;

/**
 * Created by songhongkang on 2017/12/29 0029.
 */
public class MultiJar {

    public static void main(String[] args) {
        Application.testMultiJar();
    }
}
