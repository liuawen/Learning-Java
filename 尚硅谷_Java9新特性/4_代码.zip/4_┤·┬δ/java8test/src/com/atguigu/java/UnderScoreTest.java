package com.atguigu.java;

import org.junit.Test;

/**
 * Created by songhongkang on 2017/12/29 0029.
 */
public class UnderScoreTest {

    //关于下划线的使用
    @Test
    public void testUnderScore(){
        String _ = "北京";
        System.out.println(_);

    }
}
