/**
 * Created by songhongkang on 2017/12/29 0029.
 */
module java9demo {
    //package we export
    exports com.atguigu.bean;
}