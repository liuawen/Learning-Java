/**
 * Created by songhongkang on 2017/12/29 0029.
 */
module javatest {

    requires java9demo;
    requires java.logging;
    requires junit;
    requires multijar;
    requires jdk.incubator.httpclient;
}