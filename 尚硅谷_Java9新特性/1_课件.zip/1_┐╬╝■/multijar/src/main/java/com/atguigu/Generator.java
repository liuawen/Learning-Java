package com.atguigu;

import java.util.Set;
import java.util.HashSet;
/**
 * Created by songhongkang on 2017/12/28 0028.
 */
public class Generator {

    public Set<String> createStrings() {
        Set<String> strings = new HashSet<String>();
        strings.add("Java");
        strings.add("8");
        return strings;
    }
}

