package com.atguigu;

import java.util.Set;
/**
 * Created by songhongkang on 2017/12/28 0028.
 */
public class Generator {
        
    public Set<String> createStrings() {
        return Set.of("Java", "9");
    }

}

