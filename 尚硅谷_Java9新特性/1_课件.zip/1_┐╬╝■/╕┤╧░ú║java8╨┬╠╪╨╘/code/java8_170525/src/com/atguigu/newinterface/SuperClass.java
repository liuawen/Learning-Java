package com.atguigu.newinterface;

public class SuperClass {
	
	public void method2(){
		System.out.println("SuperClass:上海");
	}
}
