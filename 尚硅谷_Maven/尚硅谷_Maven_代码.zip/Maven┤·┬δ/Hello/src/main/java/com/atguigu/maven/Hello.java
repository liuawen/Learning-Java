package com.atguigu.maven;
public class Hello {
	public String sayHello(String name){
		return "Hello "+name+"!";
	}
}