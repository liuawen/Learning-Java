package com.atguigu.maven;

public class Good {

}
